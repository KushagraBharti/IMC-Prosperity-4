from __future__ import annotations

from pathlib import Path
import sys


sys.path.append(str(Path(__file__).resolve().parent))

from research_candidate_lib import Round2ResearchTrader


class Trader(Round2ResearchTrader):
    PEPPER_MODE = "baseline"
    OSMIUM_MODE = None
    MARKET_ACCESS_FEE_BID = 3001